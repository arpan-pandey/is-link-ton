<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Admin Dashboard - Islinkton</title>
		<link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
		
		<style>
		
			body{
				background: #4A1E1E;
			}
		
			#sidebar{
				background-color: #4A1E1E;
				
				&>nav{
					border-top: 0.5px solid #6B2A2A;
					border-bottom: 0.5px solid #6B2A2A;
					
					&>a{
						&:hover{
							background: hsla(0, 45%, 30%, 0.5);
						}
					}
				}
			}
			
			#profile-icon{
				background: #5A2A2A;
			}
			
			#welcome-text{
				color: #7E3A37;
			}
			
		</style>
		
	</head>
	<body>
		<jsp:include page="../../components/admin/admin-sidebar.jsp"></jsp:include>
		<main>
			<header>
				<h1 id="page-title">Admin Dashboard</h1>
				<span id="welcome-text">Welcome back, ${user.name}!</span>
			</header>
			<section class="content-card">
    <h2>Manage Users</h2>

    <!-- Add New User Form -->
    <div style="margin-bottom: 25px; padding: 15px; border: 1px solid #ddd; border-radius: 8px;">
        <h4>Add New User</h4>
        <form action="AddUserServlet" method="post">
            <input type="text" name="name" placeholder="Full Name" required style="margin:5px;">
            <input type="email" name="email" placeholder="Email Address" required style="margin:5px;">
            <input type="password" name="password" placeholder="Password" required style="margin:5px;">
            
            <select name="role" required style="margin:5px;">
                <option value="student">Student</option>
                <option value="admin">Admin</option>
            </select>
            
            <button type="submit">Add User</button>
        </form>
    </div>

    <!-- Users List as Cards -->
    <c:forEach var="user" items="${allUsers}">
        <div class="announcement-container">
            <div class="announcement-info">
                <span class="announcement-title">${user.name}</span>
                <span class="announcement-date">${user.email}</span>
            </div>
            
            <span class="container-tag">${user.role == 'student' ? 'Student' : 'Admin'}</span>
            
            <!-- Action Buttons -->
            <form action="UpdateUserServlet" method="post" style="display:inline;">
                <input type="hidden" name="userID" value="${user.id}">
                <input type="text" name="name" value="${user.name}" size="12" style="margin:0 5px;">
                <input type="email" name="email" value="${user.email}" size="20" style="margin:0 5px;">
                
                <select name="role" style="margin:0 5px;">
                    <option value="student" ${user.role == 'student' ? 'selected' : ''}>Student</option>
                    <option value="admin" ${user.role == 'admin' ? 'selected' : ''}>Admin</option>
                </select>
                
                <button type="submit" style="margin:0 5px;">Update</button>
            </form>
            
            <form action="DeleteUserServlet" method="post" style="display:inline;" 
                  onsubmit="return confirm('Delete ${user.name}?')">
                <input type="hidden" name="email" value="${user.email}">
                <span class="container-tag" style="color:red; cursor:pointer;" onclick="this.closest('form').submit();">⨯</span>
            </form>
        </div>
    </c:forEach>
</section>
		</main>
	</body>
</html>