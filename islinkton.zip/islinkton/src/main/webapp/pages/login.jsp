<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Login - Islinkton</title>
	</head>
	<body>
	
	<h2>Login</h2>
	
	<form action="login" method="post">
	    Email: <input type="email" name="email" required><br>
	    Password: <input type="password" name="password" required><br>
	    <button type="submit">Login</button>
	</form>
	
	<% if (request.getAttribute("error") != null) { %>
    	<p style="color:red;">${error}</p>
	<% } %>
	
	<a href="${pageContext.request.contextPath}/register">Register</a>
	
	</body>
</html>