<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Register - Islinkton</title>
	</head>
	<body>
	
		<h2>Register</h2>
		
		<form action="register" method="post">
		    Name: <input type="text" name="name" required><br>
		    Email: <input type="email" name="email" required><br>
		    Password: <input type="password" name="password" required><br>
		    <button type="submit">Register</button>
		</form>
		
		<a href="${pageContext.request.contextPath}/login">Login</a>
	
	</body>
</html>